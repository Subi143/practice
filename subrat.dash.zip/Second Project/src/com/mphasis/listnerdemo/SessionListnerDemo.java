package com.mphasis.listnerdemo;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


@WebListener
public class SessionListnerDemo implements HttpSessionListener {
private int sessionCount = 0;
    
    public SessionListnerDemo() {
        
    }

    public void sessionCreated(HttpSessionEvent se)  { 
         synchronized (this) {
			sessionCount++;
		}
         System.out.println("Session Id: "+se.getSession().getId());
         System.out.println("Sessions Created"+sessionCount);
    }

    public void sessionDestroyed(HttpSessionEvent se)  { 
    	synchronized (this) {
			sessionCount--;
		}
         System.out.println("Session Id: "+se.getSession().getId());
         System.out.println("Sessions Created"+sessionCount);
    }
	
}
