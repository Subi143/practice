package com.mphasis.crypto.demo;

import java.io.IOException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;


@WebFilter("/ResponseServlet")
public class CryptoFilter implements Filter {

    
    public CryptoFilter() {
        
    }

	public void destroy() {
		
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		if (request instanceof HttpServletRequest) {
			String str = request.getParameter("strings");
			if(str != null) {
				try {
					KeyGenerator keyGenerator = KeyGenerator.getInstance("DESede");
					SecretKey secretKey = keyGenerator.generateKey();
					Cipher cipher = Cipher.getInstance("DESede");
					cipher.init(Cipher.ENCRYPT_MODE, secretKey);
					byte[] encrypted = cipher.doFinal(str.getBytes());
					
					//decryption
					
					cipher.init(Cipher.DECRYPT_MODE, secretKey);
					byte[] decrypted = cipher.doFinal(encrypted);
					
					request.setAttribute("encrypted", new String(encrypted));
					request.setAttribute("decrypted", new String(decrypted));
					
					request.getRequestDispatcher("ResponseServlet").forward(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else {
			chain.doFilter(request, response);
		}
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
