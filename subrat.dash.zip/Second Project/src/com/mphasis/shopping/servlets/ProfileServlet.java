package com.mphasis.shopping.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/profile")
public class ProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ProfileServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		/*String name = null;
		Cookie ck[] = request.getCookies();
		for (Cookie cookie : ck) {
			if(cookie.getName().equals("cname")) {
				name = cookie.getValue();
			}
		}*/
		
		response.setHeader("Cache-Control", "no-cache,no-store,must-revalidate"); //http1.0
		response.setHeader("Pragma", "no-cache"); //http older mozila firefox
		response.setHeader("Expires", "0"); //http 2.0
		try {
			HttpSession session = request.getSession(false);
			String name = session.getAttribute("sname").toString();
			session.getLastAccessedTime();
			
			out.print("<h1>Welcome To Profile "+name+"</h1><br/>");
			RequestDispatcher rd= request.getRequestDispatcher("Menu.html");
			rd.include(request, response);
		} catch (NullPointerException e) {
			out.print("<h1>Login Again</h1><br/>");
			RequestDispatcher rd= request.getRequestDispatcher("ProductProfile.html");
			rd.include(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
