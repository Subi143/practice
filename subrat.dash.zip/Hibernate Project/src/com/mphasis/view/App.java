package com.mphasis.view;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mphasis.entities.MpEmployee;
import com.mphasis.entities.Salary;
import com.mphasis.entities.Singers;
import com.mphasis.entities.Song;

public class App {
	
	public static void main(String[] args) {
		
		/*Salary salary = new Salary();
		salary.setSid(12);
		salary.setHra(12000);
		salary.setTa(1200);
		salary.setPf(6000);
		salary.setSal(14000);
		MpEmployee mpEmployee = new MpEmployee();
		mpEmployee.setEid(34);
		mpEmployee.setEname("SUBRAT");
		mpEmployee.setSalary(salary);*/
		Configuration configuration = new Configuration().configure().addAnnotatedClass(MpEmployee.class).
				addAnnotatedClass(Salary.class);
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		
		/*Session session1 = sessionFactory.openSession();
		Transaction transaction1 = session1.beginTransaction();
		session1.save(salary);
		session1.save(mpEmployee);
		transaction1.commit();
		session1.close();
		System.out.println("done");*/
		
		Session session2 = sessionFactory.openSession();
		Transaction transaction2 = session2.beginTransaction();
		MpEmployee mp2 = session2.get(MpEmployee.class, 34);
		System.out.println(mp2.getEname());
		transaction2.commit();
		session2.close();
		System.out.println("done");
		
		Session session1 = sessionFactory.openSession();
		Transaction transaction1 = session1.beginTransaction();
		MpEmployee mp1 = session1.get(MpEmployee.class, 34);
		System.out.println(mp1.getEname());
		transaction1.commit();
		session1.close();
		System.out.println("done");
		
		
		
		
		
		
		
		/*Singers singers1 = new Singers();
		singers1.setSinger_id(12);
		singers1.setName("Sumit");
		Singers singers2 = new Singers();
		singers2.setSinger_id(14);
		singers2.setName("Sudhir");
		Singers singers3 = new Singers();
		singers3.setSinger_id(16);
		singers3.setName("Swaraj");
		
		List<Singers> singers = new ArrayList<>();
		singers.add(singers1);
		singers.add(singers2);
		singers.add(singers3);
		
		Song song1 = new Song();
		song1.setSid(1);
		song1.setLyrics("Guzarish");
		song1.setSingers(singers);
		
		Song song2 = new Song();
		song2.setSid(2);
		song2.setLyrics("TeraGhata");
		song2.setSingers(singers);
		
		Song song3 = new Song();
		song3.setSid(3);
		song3.setLyrics("Dhoom");
		song3.setSingers(singers);
		
		
	
		
		List<Song> song = new ArrayList<>();
		song.add(song1);
		song.add(song2);
		song.add(song3);
		singers1.setSong(song);
		singers2.setSong(song);
		singers3.setSong(song);
		
		Configuration configuration = new Configuration().configure().addAnnotatedClass(Singers.class)
				.addAnnotatedClass(Song.class);
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(singers1);
		session.save(singers2);
		session.save(singers3);
		session.save(song1);
		session.save(song2);
		session.save(song3);
		transaction.commit();
		System.out.println("Done");*/
	}
}
