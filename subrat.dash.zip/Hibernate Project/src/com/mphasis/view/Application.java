package com.mphasis.view;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mphasis.entities.Singers;
import com.mphasis.entities.Song;

public class Application {

	public static void main(String[] args) {
		
		Song song = null;
		
		Configuration configuration = new Configuration().configure().addAnnotatedClass(Singers.class)
				.addAnnotatedClass(Song.class);
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		song = session.get(Song.class, 1);
		transaction.commit();
		System.out.println("done");
	}
}
