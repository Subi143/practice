package com.mphasis.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Song {

	@Id
	private int sid;
	private String lyrics;
	/*@OneToMany(mappedBy="song", fetch = FetchType.EAGER)*/
	
	@ManyToMany
	private List<Singers> singers = new ArrayList<>();

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getLyrics() {
		return lyrics;
	}

	public void setLyrics(String lyrics) {
		this.lyrics = lyrics;
	}

	public List<Singers> getSingers() {
		return singers;
	}

	public void setSingers(List<Singers> singers) {
		this.singers = singers;
	}
	
	

}
