package com.mphasis.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class Singers {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long singer_id;
	private String name;
	@ManyToMany
	private List<Song> song=new ArrayList<>();

	public long getSinger_id() {
		return singer_id;
	}

	public void setSinger_id(long singer_id) {
		this.singer_id = singer_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Song> getSong() {
		return song;
	}

	public void setSong(List<Song> song) {
		this.song = song;
	}

}
