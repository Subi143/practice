package com.mphasis;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mphasis.pojo.MediaTech;
import com.mphasis.pojo.Phone;

public class PhoneApp {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		
		//xml way
		/*Phone phone = (Phone) context.getBean("phone1");
		System.out.println(phone.getPhone_model()+" "+phone.getCamera()+" "+phone.getProcessor());
		Phone phone1 = (Phone) context.getBean("phone2");
		System.out.println(phone1.getPhone_model()+" "+phone1.getCamera()+" "+phone1.getProcessor());*/
		
		//MediaTech mediaTech = (MediaTech) context.getBean("mediaTech");
		
	
		Phone phone = (Phone) context.getBean("phone");
		phone.setPhone_model("Vivo v10");
		phone.setCamera("20px 5px");
		//phone.setProcessor(mediaTech);
		System.out.println(phone.getPhone_model()+" "+phone.getCamera()+" "+phone.getProcessor());
	}
}
