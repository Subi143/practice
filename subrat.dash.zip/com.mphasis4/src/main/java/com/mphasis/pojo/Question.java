package com.mphasis.pojo;

import java.util.Map;

public class Question {

	private int qstn_num;
	private String qstn;
	private Map<User,Answer> answer;

	public int getQstn_num() {
		return qstn_num;
	}

	public void setQstn_num(int qstn_num) {
		this.qstn_num = qstn_num;
	}

	public String getQstn() {
		return qstn;
	}

	public void setQstn(String qstn_name) {
		this.qstn = qstn_name;
	}

	public Map<User,Answer> getAnswer() {
		return answer;
	}

	public void setAnswer(Map<User,Answer> answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "Question [qstn_num=" + qstn_num + ", qstn=" + qstn + " " + answer + "]";
	}

}
