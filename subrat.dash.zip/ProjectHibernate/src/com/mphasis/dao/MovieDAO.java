package com.mphasis.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mphasis.entities.Movie;
import com.mphasis.util.HibernateUtil;

public class MovieDAO {

	public void addMovie(Movie movie) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			session.save(movie);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
	}

	public void removeMovie(int movieId) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			Movie m = session.get(Movie.class, movieId);
			session.delete(m);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
	}
	
	public void editMovie(Movie movie) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			session.update(movie);
			transaction.commit();
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
	}
	

	public Movie getMovieById(int movieId) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Movie m = session.get(Movie.class, movieId);
			return m;
		}
	}

	public List<Movie> getAllMovies() {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			return session.createQuery("From Movie", Movie.class).list();
		}
	}
}
