package com.mphasis.view;

import java.util.List;
import java.util.Scanner;

import com.mphasis.dao.MovieDAO;
import com.mphasis.entities.Movie;

public class MovieApp {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Welcome");
		MovieDAO movieDAO = new MovieDAO();
		System.out.println("1.Add Movies \n2.Update Movie \n3.Delete Movie \n4.Show Movie By Id \n5.Show All");
		System.out.println("Enter Choice: ");
		int choice = scanner.nextInt();
		
		switch (choice) {
				
		case 1: System.out.println("Enter Movie Details");
				Movie m = new Movie();
				m.setMovieId(scanner.nextInt());
				m.setMovieName(scanner.next());
				m.setTheaterName(scanner.next());
				m.setRatings(scanner.nextDouble());
				movieDAO.addMovie(m);
				System.out.println("Movie Added");
				break;
				
		case 2: System.out.println("Enter Update Details");
				Movie m1 = new Movie();
				m1.setMovieId(scanner.nextInt());
				m1.setMovieName(scanner.next());
				movieDAO.editMovie(m1);
				System.out.println("Movie Updated");
				break;
				
		case 3: System.out.println("Enter Id Of Movie Which You Want To Delete");
				movieDAO.removeMovie(scanner.nextInt());
				System.out.println("Movie Deleted");
				break;
				
		case 4: System.out.println("Enter Id Of Movie Which You Want To See");
				int id = scanner.nextInt();
				Movie m2 = movieDAO.getMovieById(id);
				System.out.println("Movie Details Displayed"+m2.getMovieName());
				break;
				
		case 5: List<Movie> movies = movieDAO.getAllMovies();
				for (Movie movie : movies) {
					System.out.println(movie.getMovieId()+" " +movie.getMovieName()+" "+movie.getTheaterName()+" "+movie.getRatings());
				}
				break;
		default: System.out.println("Invalid Choice");
				 System.exit(0);	
	  }
		
	}
}
