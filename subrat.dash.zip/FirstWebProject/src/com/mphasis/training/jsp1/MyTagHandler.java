package com.mphasis.training.jsp1;

import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;import org.eclipse.jdt.internal.compiler.ast.ThrowStatement;

public class MyTagHandler extends TagSupport {
	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();
		try {
			out.print(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return SKIP_BODY;
	}
}