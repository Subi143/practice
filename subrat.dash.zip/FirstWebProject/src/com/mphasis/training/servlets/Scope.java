package com.mphasis.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(
		urlPatterns = { "/Scope" }, 
		initParams = { 
				@WebInitParam(name = "n1", value = "10")
		})
public class Scope extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Scope() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		out.print("Scope Demo <br/>");
		
		String rname = request.getParameter("un");
		out.print("Request Parameter "+rname+"<br/>");
		
		ServletConfig cname = getServletConfig();
		out.print("Configuration Parameter "+cname.getInitParameter("n1")+"<br/>");
		
		HttpSession session = request.getSession();
		session.setAttribute("sname", rname);
		out.print("Session Value "+session.getAttribute("sname")+"<br/>");
		
		ServletContext context = request.getServletContext();
		out.print("Context Value "+context.getInitParameter("driver")+"<br/>");
		
		
		
 	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
