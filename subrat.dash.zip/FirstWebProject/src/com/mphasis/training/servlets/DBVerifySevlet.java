package com.mphasis.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.bo.LoginBO;
import com.bo.LoginBOImpl;
import com.exception.BusinessException;
import com.model.User;

public class DBVerifySevlet extends GenericServlet {
	public void service(ServletRequest request, ServletResponse responce) throws IOException, ServletException {

		PrintWriter out = responce.getWriter();
		responce.setContentType("text/html");
		String uname = request.getParameter("un");
		String password = request.getParameter("pw");
		User user = new User();
		user.setUsername(request.getParameter("un"));
		user.setPassword(request.getParameter("pw"));
		LoginBO loginBO = new LoginBOImpl();
		try {
			if(loginBO.isValidUser(user)) {
				out.println("Welcome "+ user.getUsername()+" \nLast Login "+new Date());
			}
		} catch (BusinessException e) {
			out.println(e.getMessage());
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.html");
			dispatcher.include(request, responce);
		}
	}
}
