package com.mphasis.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class LoginServlet extends GenericServlet {

	public void service(ServletRequest request, ServletResponse responce) throws IOException, ServletException {

			PrintWriter out = responce.getWriter();
			responce.setContentType("text/html");
			String uname = request.getParameter("un");
			String password = request.getParameter("pw");
			if (uname.startsWith("R")) {
				out.print("Welcome "+uname);
			} else {
				out.print("Invalid Credentials...");
				RequestDispatcher dispatcher = request.getRequestDispatcher("login.html");
				dispatcher.include(request, responce);
			}
	}

}
