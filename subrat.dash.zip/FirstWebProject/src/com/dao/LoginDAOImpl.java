package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dbutil.OracleDBConnection;
import com.exception.BusinessException;
import com.model.User;

public class LoginDAOImpl implements LoginDAO {

	@Override
	public boolean isValidUser(User user) throws BusinessException {
		boolean b = false;
		String sql = "select username from loginmaster where username = ? and password = ?";
		try(Connection connection = OracleDBConnection.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, user.getUsername());
			preparedStatement.setString(2, user.getPassword());
			
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()) {
				b = true;
			} else {
				throw new BusinessException("Invalid Login Credentials");
			}
		} catch (ClassNotFoundException | SQLException e) {
			throw new BusinessException("Internal Error Occured... Kindly Check");
		}
		return b;
	}

}
