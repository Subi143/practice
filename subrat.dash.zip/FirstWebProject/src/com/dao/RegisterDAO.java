package com.dao;

import com.exception.BusinessException;
import com.model.User;

public interface RegisterDAO {
	public int registerUserInfo(User user) throws BusinessException;
}
