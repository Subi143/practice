package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dbutil.OracleDBConnection;
import com.exception.BusinessException;
import com.model.User;

public class RegisterDAOImpl implements RegisterDAO{

	@Override
	public int registerUserInfo(User user) throws BusinessException {
		int b = 0;
		String sql = "insert into loginmaster(username, password) values (?, ?)";
		try(Connection connection = OracleDBConnection.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, user.getUsername());
			preparedStatement.setString(2, user.getPassword());
			
			b = preparedStatement.executeUpdate();
			
			
			
		} catch (ClassNotFoundException | SQLException e) {
			if(e.getMessage().contains("unique"))
				System.out.println("Value Already Present...");
			else
				System.out.println(e);
		}
		return b;
	}

}
