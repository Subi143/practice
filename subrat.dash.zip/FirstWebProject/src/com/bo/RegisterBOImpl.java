package com.bo;

import com.dao.LoginDAO;
import com.dao.LoginDAOImpl;
import com.dao.RegisterDAO;
import com.dao.RegisterDAOImpl;
import com.exception.BusinessException;
import com.model.User;

public class RegisterBOImpl implements RegisterBo {

	@Override
	public int registerUserInfo(User user) throws BusinessException {
		int b = 0;
		
		if(user != null && user.getUsername() != null && user.getPassword() != null) {
			if(user.getUsername().matches("[a-zA-Z]{4,7}[0-9]{4}")) {
				if (user.getPassword().matches("[a-z]{3,5}@[0-9]{3}")) {
					
					RegisterDAO registerDAO = new RegisterDAOImpl();
					b = registerDAO.registerUserInfo(user);
					
				} else {
					throw new BusinessException("Invalid Password .... example abc@123");
				}
			} else {
				throw new BusinessException("Invalid Username .... example abcd1234");
			}
		} else {
			throw new BusinessException("Username/Password Must Not Blank...");
		}
		return b;
	}

}
