package com.bo;

import com.exception.BusinessException;
import com.model.User;

public interface RegisterBo {
	public int registerUserInfo(User user) throws BusinessException;
}
