package com.bo;

import com.dao.LoginDAO;
import com.dao.LoginDAOImpl;
import com.exception.BusinessException;
import com.model.User;

public class LoginBOImpl implements LoginBO{

	@Override
	public boolean isValidUser(User user) throws BusinessException {
		boolean b = false;
		
		if(user != null && user.getUsername() != null && user.getPassword() != null 
				&& user.getUsername().matches("[a-zA-Z]{4,7}[0-9]{4}")
				&& user.getPassword().matches("[a-z]{3,5}@[0-9]{3}")) {
			
			//Code here for DAO
			LoginDAO loginDAO = new LoginDAOImpl();
			b = loginDAO.isValidUser(user);
		} else {
			throw new BusinessException("Invalid Username or Password");
		}
		
		return b;
	}

}
