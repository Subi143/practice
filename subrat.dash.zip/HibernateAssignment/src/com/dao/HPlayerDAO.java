package com.dao;

import java.util.ArrayList;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.query.Query;

import com.entities.HPlayer;
import com.hibernateutil.HibernateUtil;

public class HPlayerDAO {

	public List<HPlayer> getPlayerById(int pId) {
		List<HPlayer> h = new ArrayList<>();
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Query query = session.createQuery("from HPlayer where id = :pname");
			query.setParameter("pname", pId);
			h = query.getResultList();
		}
		return h;
	}
	
	public List<HPlayer> getPlayerByName(String pName) {
		List<HPlayer> h = new ArrayList<>();
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Query query = session.createQuery("from HPlayer where name = :pname");
			query.setParameter("pname", pName);
			h = query.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return h;
	}
	
	public List<HPlayer> getPlayerByAge(int pAge) {
		List<HPlayer> h = new ArrayList<>();
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Query query = session.createQuery("from HPlayer where age = :pAge");
			query.setParameter("pAge", pAge);
			h = query.getResultList();
		}
		return h;
	}
	
	public List<HPlayer> getPlayerByGender(String pGender) {
		List<HPlayer> h = new ArrayList<>();
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Query query = session.createQuery("from HPlayer where gender = :gender");
			query.setParameter("gender", pGender);
			h = query.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return h;
	}
	
	public List<HPlayer> getPlayerByEmail(String email) {
		List<HPlayer> h = new ArrayList<>();
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Query query = session.createQuery("from HPlayer where email = :email");
			query.setParameter("email", email);
			h = query.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return h;
	}
	
	public List<HPlayer> getPlayerByTeamname(String teamname) {
		List<HPlayer> h = new ArrayList<>();
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Query query = session.createQuery("from HPlayer where teamname = :teamname");
			query.setParameter("teamname", teamname);
			h = query.getResultList();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return h;
	}
	
	public List<HPlayer> getPlayerByContact(long contact) {
		List<HPlayer> h = new ArrayList<>();
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Query query = session.createQuery("from HPlayer where contact = :contact");
			query.setParameter("contact", contact);
			h = query.getResultList();
		}
		return h;
	}
	
}
