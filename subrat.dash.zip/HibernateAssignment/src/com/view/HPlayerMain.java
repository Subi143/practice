package com.view;

import java.util.List;
import java.util.Scanner;

import com.dao.HPlayerDAO;
import com.entities.HPlayer;


public class HPlayerMain {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter contact To Search:");
		long contact = scanner.nextLong();
		HPlayerDAO hPlayerDAO = new HPlayerDAO();
		List<HPlayer> hPlayer = hPlayerDAO.getPlayerByContact(contact);
		
		for (HPlayer hPlayer2 : hPlayer) {
			System.out.println(hPlayer2);
		}
	}
}