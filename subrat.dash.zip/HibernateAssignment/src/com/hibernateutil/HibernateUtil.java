package com.hibernateutil;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import com.entities.HPlayer;


public class HibernateUtil {
	private static SessionFactory sessionFactory;
	
	public static SessionFactory getSessionFactory() {
		if(sessionFactory == null)
			try {
				Configuration configuration = new Configuration();
				Properties properties = new Properties();
				properties.put(Environment.DRIVER, "oracle.jdbc.OracleDriver");
				properties.put(Environment.URL, "jdbc:oracle:thin:@localhost:1521:xe");
				properties.put(Environment.USER, "subrat");
				properties.put(Environment.PASS, "123");
				properties.put(Environment.DIALECT, "org.hibernate.dialect.OracleDialect");
				properties.put(Environment.SHOW_SQL, "true");
				properties.put(Environment.HBM2DDL_AUTO, "update");
				
				configuration.setProperties(properties);
				configuration.addAnnotatedClass(HPlayer.class);
				sessionFactory = configuration.buildSessionFactory();
				return sessionFactory;
			} catch (Exception e) {
				e.printStackTrace();
			}
		return sessionFactory;
		}
 }