package com.junit;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class JunitDemo1 {
	
	Calculator calculator = new Calculator();
	CharTest chartest = new CharTest();
	
	/*@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Set Up Before Class Testcase");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Tear Down After Class Testcase");
	}

	@Before
	public void setUp() throws Exception {
		calculator = new Calculator(); 
		chartest = new CharTest();
		System.out.println("Set Up Testcase");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Tear Down Testcase");
		
	}
*/
	/*@Test
	public void testAdd() {
		assertEquals(50, calculator.add(40,10));
		assertEquals(110, calculator.add(85,25));
	}
	

	@Test
	public void testSub() {
		assertEquals(-97, calculator.sub(8, 105));
		assertEquals(69, calculator.sub(79,10));
	}*/
	
	@Test
	public void testChar() {
		assertEquals("CD", chartest.removeA("AACD"));
		assertEquals(true, chartest.firstLastSame("APGHVCVFAP"));
	}

}
