package com.junit;

import java.util.Arrays;

import static org.junit.Assert.*;

import org.junit.Test;

public class JunitDemo2 {
	
	@Test
	public void testArray() {
		int actual[] = {12,45,86,2,34,1,8,97};
		Arrays.sort(actual);
		int expected[] = {1,2,8,12,34,45,86,97};
		assertArrayEquals(expected, actual);
	}
	
	@Test(expected = NullPointerException.class)
	public void testValue() {
		int arr[] = null;
		Arrays.sort(arr);
	}
	
	@Test(timeout=50)
	public void testPerformance() {
		for (int i = 0; i < 1000000; i++) {
			int arr[] = {i, i-1, i+1};
			Arrays.sort(arr);
		}
	}
}
