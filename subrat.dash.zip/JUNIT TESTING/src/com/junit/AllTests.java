package com.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ JunitDemo1.class, JunitDemo2.class, JunitDemo3.class })
public class AllTests {

}
