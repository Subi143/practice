package com.junit;

public class CharTest {
	
	public String removeA(String str) {
		String newString = null;
		int length = str.length();
		if(str.charAt(0) == 'A' || str.charAt(1) == 'A') {
			newString = str.substring(0, 2).replace("A", "").concat(str.substring(2, length));
		} else
		{
			newString = str;
		}
		return newString;
	}
	
	public boolean firstLastSame(String str) {
		boolean stmt = true;
		char[] ch = str.toCharArray();
		int length = ch.length;
		
		if(ch[0] != ch[length-2] || ch[1] != ch[length-1])
			stmt = false;
		return stmt;
	}
}
