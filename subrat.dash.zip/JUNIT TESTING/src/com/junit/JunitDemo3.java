package com.junit;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class JunitDemo3 {
	
	CharTest charTest = new CharTest();
	private String actualInput;
	private String expected;
	
	public JunitDemo3(String actualInput, String expected) {
		this.actualInput = actualInput;
		this.expected = expected;
	}
	
	@Parameters
	public static Collection<String[]> toConditions() {
		String expectedConditions[][] = { {"AACD", "CD"}, {"ABCD", "BCD"}, {"CDAA", "CDAA"}, {"ADAA", "DAA"} };
		return Arrays.asList(expectedConditions);
	}
	
	@Test
	public void testCharFirstTwo() {
		assertEquals(expected, charTest.removeA(actualInput));
	}
}
