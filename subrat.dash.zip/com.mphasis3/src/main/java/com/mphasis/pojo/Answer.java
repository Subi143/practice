package com.mphasis.pojo;

public class Answer {

	private int ans_num;
	private String ans;

	public int getAns_num() {
		return ans_num;
	}

	public void setAns_num(int ans_num) {
		this.ans_num = ans_num;
	}

	public String getAns() {
		return ans;
	}

	public void setAns(String ans) {
		this.ans = ans;
	}

	@Override
	public String toString() {
		return "ans_num=" + ans_num + ", ans=" + ans + "]";
	}

	
}
