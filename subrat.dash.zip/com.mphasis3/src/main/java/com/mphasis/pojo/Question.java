package com.mphasis.pojo;

import java.util.List;

public class Question {

	private int qstn_num;
	private String qstn;
	private List<Answer> answer;

	public int getQstn_num() {
		return qstn_num;
	}

	public void setQstn_num(int qstn_num) {
		this.qstn_num = qstn_num;
	}

	public String getQstn() {
		return qstn;
	}

	public void setQstn(String qstn_name) {
		this.qstn = qstn_name;
	}

	public List<Answer> getAnswer() {
		return answer;
	}

	public void setAnswer(List<Answer> answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "Question [qstn_num=" + qstn_num + ", qstn=" + qstn + " " + answer + "]";
	}

}
