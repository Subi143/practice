package com.mphasis.view;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mphasis.pojo.Question;

public class QuestionApp {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Question question = (Question) context.getBean("question");

		System.out.println(question);
	}
}
