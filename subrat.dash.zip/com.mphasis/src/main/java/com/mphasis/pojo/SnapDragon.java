package com.mphasis.pojo;

import org.springframework.stereotype.Component;

@Component
public class SnapDragon implements Processor{
	
	public void process() {
		System.out.println("SnapDragon is no.1 processor.");
	}
	
	@Override
	public String toString() {
		return "SnapDragon[]";
		
	}
}
