package com.mphasis.pojo;

public class Account {

	private int acc_num;
	private String name;
	private double balance;
	
	

	public Account() {
		System.out.println("Account Started");
	}

	/*public Account(int acc_num, String name, double balance) {
		this.acc_num = acc_num;
		this.name = name;
		this.balance = balance;
	}*/

	public int getAcc_num() {
		return acc_num;
	}

	public void setAcc_num(int acc_num) {
		this.acc_num = acc_num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

}
