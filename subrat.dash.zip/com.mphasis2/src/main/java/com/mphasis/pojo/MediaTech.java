package com.mphasis.pojo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class MediaTech implements Processor {
	
	public void process() {
		System.out.println("MediaTech is no.2 processor.");
	}
	
	@Override
	public String toString() {
		return "MediaTech[]";
	}
}
