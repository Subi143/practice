package com.mphasis.pojo;

public interface Processor {

	public void process();
}
