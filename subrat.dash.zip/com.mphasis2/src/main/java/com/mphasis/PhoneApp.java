package com.mphasis;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mphasis.config.AppConfig;
import com.mphasis.pojo.MediaTech;
import com.mphasis.pojo.Phone;

public class PhoneApp {

	public static void main(String[] args) {
		
		//third and easiest way
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		
	
		Phone phone = (Phone) context.getBean("phone");
		phone.setPhone_model("Vivo v10");
		phone.setCamera("20px 5px");
		//phone.setProcessor(mediaTech);
		System.out.println(phone.getPhone_model()+" "+phone.getCamera()+" "+phone.getProcessor());
	}
}
