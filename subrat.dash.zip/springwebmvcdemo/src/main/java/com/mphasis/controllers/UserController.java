package com.mphasis.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mphasis.entities.Fuser;
import com.mphasis.services.FuserService;

@Controller
public class UserController {

	@Autowired
	FuserService fuserService;
	
	@RequestMapping("/login")
	public ModelAndView login(@RequestParam("uname")String uname, @RequestParam("pwd")String pass) {
		
		ModelAndView mv = new ModelAndView();
		Fuser fuser =  fuserService.signinFuser(uname, pass);
		
		if(fuser!=null) {
			mv.setViewName("hello");
			mv.addObject("uname", uname);
		} else {
			mv.setViewName("index");
			mv.addObject("message", "Invalid Details");
		}
		
		return mv;
	}
}
