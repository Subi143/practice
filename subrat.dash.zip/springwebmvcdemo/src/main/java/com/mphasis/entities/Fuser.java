package com.mphasis.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Fuser {

	@Id
	private int fuid;
	private String funame;
	private String fpass;
	private char gender;
	private String dob;
	private long phnno;
	private String email;

	public int getFuid() {
		return fuid;
	}

	public void setFuid(int fuid) {
		this.fuid = fuid;
	}

	public String getFuname() {
		return funame;
	}

	public void setFuname(String funame) {
		this.funame = funame;
	}

	public String getFpass() {
		return fpass;
	}

	public void setFpass(String fpass) {
		this.fpass = fpass;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public long getPhnno() {
		return phnno;
	}

	public void setPhnno(long phnno) {
		this.phnno = phnno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
