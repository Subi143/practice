package com.mphasis.dao;

import com.mphasis.entities.Fuser;

public interface FuserDao {
	public Fuser signinFuser(String un, String pw);
}
