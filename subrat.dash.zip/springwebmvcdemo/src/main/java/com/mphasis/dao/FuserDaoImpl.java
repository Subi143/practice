package com.mphasis.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.entities.Fuser;

@Repository
public class FuserDaoImpl implements FuserDao {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Fuser signinFuser(String funame, String fpass) {
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("from Fuser where funame =:funame and fpass =:fpass");
		query.setParameter("funame", funame);
		query.setParameter("fpass", fpass);
		Fuser fuser = (Fuser) query.uniqueResult();
		transaction.commit();
		return fuser;
	}

}
