package com.mphasis.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.dao.FuserDao;
import com.mphasis.entities.Fuser;

@Service
public class FuserServiceImpl implements FuserService {

	@Autowired
	FuserDao fuserDao;

	public void setFuserDao(FuserDao fuserDao) {
		this.fuserDao = fuserDao;
	}

	public Fuser signinFuser(String un, String pw) {
		Fuser fuser = fuserDao.signinFuser(un, pw);
		return fuser;
	}

}
