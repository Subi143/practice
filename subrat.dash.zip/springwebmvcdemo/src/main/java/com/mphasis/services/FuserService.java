package com.mphasis.services;

import com.mphasis.entities.Fuser;

public interface FuserService {
	public Fuser signinFuser(String un, String pw);
}
