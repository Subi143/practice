package com.mphasis.springhibernate;

import java.util.List;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mphasis.entities.Product;
import com.mphasis.services.ProductService;
import com.mphasis.services.ProductServiceImpl;

public class App 
{
    public static void main( String[] args )
    {
    	Scanner scanner = new Scanner(System.in);
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("application.xml");
        ProductService productService = (ProductService) applicationContext.getBean("productServiceImpl"); 
        
        /*addProduct(productService);*/
        
        /*editProduct(productService);*/
        
        System.out.println("Enter Id: ");
        int id = scanner.nextInt();
        
       /* productService.removeProduct(id);*/
        
        Product productById = productService.getProductById(id);
        System.out.println(productById);
        
      /* List<Product> product = productService.getAllProduct();
        
        for (Product product2 : product) {
			System.out.println(product2);
		}*/
       
    }
    
    /*public static void addProduct(ProductService productService) {
    	Product product = new Product();
    	product.setPid(200);
    	product.setName("Ipad");
    	product.setBrand("Apple");
    	product.setCost(65000);
    	product.setQuantity(1);
    	product.setDiscount(30);
    	productService.addProduct(product);
    	System.out.println("Products Added....");
    }*/
    
    /*public static void editProduct(ProductService productService) {
    	Product product = new Product();
    	product.setPid(100);
    	product.setName("Macbook");
    	product.setBrand("Apple");
    	product.setCost(125000);
    	product.setQuantity(1);
    	product.setDiscount(15);
    	productService.editProduct(product);
    	System.out.println("Products Updated....");
    }*/
    
    
    
    
    
    
    
}