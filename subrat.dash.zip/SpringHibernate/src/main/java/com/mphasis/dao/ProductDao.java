package com.mphasis.dao;

import java.util.List;

import com.mphasis.entities.Product;

public interface ProductDao {
	public void insertProduct(Product product);
	public void updateProduct(Product product);
	public void deleteProduct(int id);
	public Product retriveProductById(int id);
	public List<Product>  retriveAllProduct();
}
