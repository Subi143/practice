package com.mphasis.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mphasis.entities.Product;

@Repository
public class ProductDaoImpl implements ProductDao {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void insertProduct(Product product) {
		Session session =sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		session.save(product);
		transaction.commit();
	}

	public void updateProduct(Product product) {
		Session session =sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		session.update(product);
		transaction.commit();
	}

	public void deleteProduct(int id) {
		Session session =sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		Product product = (Product) session.get(Product.class, id);
		session.delete(product);
		transaction.commit();
	}

	public Product retriveProductById(int pid) {
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		return (Product) session.get(Product.class, pid);
	}

	public List<Product> retriveAllProduct() {
		Session session = sessionFactory.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		return session.createQuery("from Product").list();
	}

}
