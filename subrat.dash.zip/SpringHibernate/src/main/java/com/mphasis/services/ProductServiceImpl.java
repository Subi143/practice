package com.mphasis.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.dao.ProductDao;
import com.mphasis.entities.Product;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductDao productDao;

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	public void addProduct(Product product) {
		productDao.insertProduct(product);
	}

	public void editProduct(Product product) {
		productDao.updateProduct(product);
	}

	public void removeProduct(int id) {
		productDao.deleteProduct(id);
	}

	public Product getProductById(int id) {
		return productDao.retriveProductById(id);
	}

	public List<Product> getAllProduct() {
		return productDao.retriveAllProduct();
	}

}
