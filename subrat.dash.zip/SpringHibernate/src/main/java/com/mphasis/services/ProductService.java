package com.mphasis.services;

import java.util.List;

import com.mphasis.entities.Product;

public interface ProductService {
	public void addProduct(Product product);
	public void editProduct(Product product);
	public void removeProduct(int id);
	public Product getProductById(int id);
	public List<Product> getAllProduct();
}
