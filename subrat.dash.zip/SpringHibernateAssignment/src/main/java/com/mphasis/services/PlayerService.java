package com.mphasis.services;

import com.mphasis.entities.Player;

public interface PlayerService {
	public void signupPlayer(Player player);
	public boolean signinPlayer(String un, String pw);
}
