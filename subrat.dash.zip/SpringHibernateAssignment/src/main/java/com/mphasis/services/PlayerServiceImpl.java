package com.mphasis.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.dao.PlayerDao;
import com.mphasis.entities.Player;

@Service
public class PlayerServiceImpl implements PlayerService {

	@Autowired
	PlayerDao playerDao;

	public void setPlayerDao(PlayerDao playerDao) {
		this.playerDao = playerDao;
	}

	public void signupPlayer(Player player) {
		playerDao.signupPlayer(player);
	}

	public boolean signinPlayer(String un, String pw) {
		Player player = playerDao.signinPlayer(un, pw);
		String username = player.getUname();
		String password = player.getPassword();
		if(username.equals(un) && password.equals(pw))
			return true;
		else
			return false;
	}

}
