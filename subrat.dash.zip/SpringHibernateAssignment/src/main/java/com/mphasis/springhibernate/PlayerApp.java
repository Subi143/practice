package com.mphasis.springhibernate;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mphasis.entities.Player;
import com.mphasis.services.PlayerService;
public class PlayerApp {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("application.xml");
        PlayerService playerService = (PlayerService) applicationContext.getBean("playerServiceImpl");
        
		System.out.println("Welcome To Our App");
		System.out.println("1.Signup \n2.Signin");
		System.out.println("Enter Choice: ");
		int choice  = scanner.nextInt(); 
		
		switch(choice) {
		
		case 1: System.out.println("Enter Details");
				Player player = new Player();
				System.out.println("Enter Username: ");
				String username = scanner.next();
				System.out.println("Enter Password: ");
				String password = scanner.next();
				player.setUname(username);
				player.setPassword(password);
				playerService.signupPlayer(player);
				System.out.println("Signup Done....");
				break;
				
		case 2: System.out.println("Enter Username: ");
				String username1 = scanner.next();
				System.out.println("Enter Password: ");
				String password1 = scanner.next();
				try {
				boolean rs = playerService.signinPlayer(username1, password1);
				if(rs)
					System.out.println("Login Successful");
				} catch (Exception e) {
					System.out.println("Login Failed");
				}
				break;
				
		default: System.out.println("Invalid Choice.....");
				 System.exit(0);
		}
	}
}
