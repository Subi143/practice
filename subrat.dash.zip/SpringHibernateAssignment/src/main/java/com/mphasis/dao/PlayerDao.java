package com.mphasis.dao;

import com.mphasis.entities.Player;

public interface PlayerDao {
	public void signupPlayer(Player player);
	public Player signinPlayer(String un, String pw);
}
